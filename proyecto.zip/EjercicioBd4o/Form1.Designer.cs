﻿namespace EjercicioBd4o
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripDropDownButton2 = new System.Windows.Forms.ToolStripDropDownButton();
            this.salirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.ventanaOrdenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.txtDireccionp = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btncancelm = new System.Windows.Forms.Button();
            this.btnBuscarp = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.txtbuscar = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.btnConsultaG = new System.Windows.Forms.Button();
            this.btnGuardarp = new System.Windows.Forms.Button();
            this.TxtId_Cp = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BtnModificarP = new System.Windows.Forms.Button();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.btnAgregar = new System.Windows.Forms.Button();
            this.txtTelefonop = new System.Windows.Forms.TextBox();
            this.txtCorreop = new System.Windows.Forms.TextBox();
            this.txtNombrep = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.txtNo_Orden = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.btncanceld = new System.Windows.Forms.Button();
            this.btnbuscarD = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.txtId_Ct1 = new System.Windows.Forms.TextBox();
            this.btnConsultaD = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.label15 = new System.Windows.Forms.Label();
            this.btnGuardarD = new System.Windows.Forms.Button();
            this.btnModificarD = new System.Windows.Forms.Button();
            this.btneliminarD = new System.Windows.Forms.Button();
            this.btnagregarD = new System.Windows.Forms.Button();
            this.txtHora = new System.Windows.Forms.TextBox();
            this.txtFecha = new System.Windows.Forms.TextBox();
            this.txtId_Ct = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button7 = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.txtId_VO2 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.txtCosto = new System.Windows.Forms.TextBox();
            this.txtAncho_v = new System.Windows.Forms.TextBox();
            this.txtLargo_v = new System.Windows.Forms.TextBox();
            this.txtTipo_Ventana = new System.Windows.Forms.TextBox();
            this.txtId_VO = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.fensterDataSet1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.fensterDataSet1 = new EjercicioBd4o.FensterDataSet1();
            this.peliculaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.txtId_Ce = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.No_Orden = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Id_C = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.toolStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fensterDataSet1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fensterDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.peliculaBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.Teal;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripDropDownButton2,
            this.toolStripDropDownButton1,
            this.toolStripButton1});
            this.toolStrip1.Location = new System.Drawing.Point(0, 36);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Padding = new System.Windows.Forms.Padding(0, 0, 3, 0);
            this.toolStrip1.Size = new System.Drawing.Size(799, 38);
            this.toolStrip1.TabIndex = 15;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripDropDownButton2
            // 
            this.toolStripDropDownButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.salirToolStripMenuItem});
            this.toolStripDropDownButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton2.Image")));
            this.toolStripDropDownButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton2.Name = "toolStripDropDownButton2";
            this.toolStripDropDownButton2.Size = new System.Drawing.Size(90, 33);
            this.toolStripDropDownButton2.Text = "Archivo";
            // 
            // salirToolStripMenuItem
            // 
            this.salirToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("salirToolStripMenuItem.Image")));
            this.salirToolStripMenuItem.Name = "salirToolStripMenuItem";
            this.salirToolStripMenuItem.Size = new System.Drawing.Size(147, 34);
            this.salirToolStripMenuItem.Text = "Salir";
            this.salirToolStripMenuItem.Click += new System.EventHandler(this.salirToolStripMenuItem_Click);
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.ventanaOrdenToolStripMenuItem});
            this.toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton1.Image")));
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(78, 33);
            this.toolStripDropDownButton1.Text = "Tablas";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.ShowShortcutKeys = false;
            this.toolStripMenuItem1.Size = new System.Drawing.Size(227, 34);
            this.toolStripMenuItem1.Text = "Cliente";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(227, 34);
            this.toolStripMenuItem2.Text = "Cita";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // ventanaOrdenToolStripMenuItem
            // 
            this.ventanaOrdenToolStripMenuItem.Name = "ventanaOrdenToolStripMenuItem";
            this.ventanaOrdenToolStripMenuItem.Size = new System.Drawing.Size(227, 34);
            this.ventanaOrdenToolStripMenuItem.Text = "VentanaOrden";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(34, 33);
            this.toolStripButton1.Text = "Ayuda";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(799, 36);
            this.menuStrip1.TabIndex = 16;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(203, 75);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 20);
            this.label1.TabIndex = 17;
            this.label1.Text = "FENSTER";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.label4.Image = ((System.Drawing.Image)(resources.GetObject("label4.Image")));
            this.label4.Location = new System.Drawing.Point(4, 3);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(550, 31);
            this.label4.TabIndex = 14;
            this.label4.Text = "Programa Utilizando Base de Datos O O";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(0, 100);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(786, 506);
            this.tabControl1.TabIndex = 23;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.tabPage1.Controls.Add(this.txtDireccionp);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.btncancelm);
            this.tabPage1.Controls.Add(this.btnBuscarp);
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Controls.Add(this.txtbuscar);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Controls.Add(this.btnConsultaG);
            this.tabPage1.Controls.Add(this.btnGuardarp);
            this.tabPage1.Controls.Add(this.TxtId_Cp);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Controls.Add(this.BtnModificarP);
            this.tabPage1.Controls.Add(this.btnEliminar);
            this.tabPage1.Controls.Add(this.btnAgregar);
            this.tabPage1.Controls.Add(this.txtTelefonop);
            this.tabPage1.Controls.Add(this.txtCorreop);
            this.tabPage1.Controls.Add(this.txtNombrep);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPage1.Size = new System.Drawing.Size(778, 473);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Cliente";
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // txtDireccionp
            // 
            this.txtDireccionp.Location = new System.Drawing.Point(82, 157);
            this.txtDireccionp.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtDireccionp.Name = "txtDireccionp";
            this.txtDireccionp.Size = new System.Drawing.Size(148, 26);
            this.txtDireccionp.TabIndex = 33;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.label9.Location = new System.Drawing.Point(9, 157);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(75, 20);
            this.label9.TabIndex = 32;
            this.label9.Text = "Direccion";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // btncancelm
            // 
            this.btncancelm.Location = new System.Drawing.Point(506, 8);
            this.btncancelm.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btncancelm.Name = "btncancelm";
            this.btncancelm.Size = new System.Drawing.Size(112, 35);
            this.btncancelm.TabIndex = 31;
            this.btncancelm.Text = "Cancelar";
            this.btncancelm.UseVisualStyleBackColor = true;
            this.btncancelm.Visible = false;
            this.btncancelm.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnBuscarp
            // 
            this.btnBuscarp.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.btnBuscarp.Image = ((System.Drawing.Image)(resources.GetObject("btnBuscarp.Image")));
            this.btnBuscarp.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBuscarp.Location = new System.Drawing.Point(462, 119);
            this.btnBuscarp.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnBuscarp.Name = "btnBuscarp";
            this.btnBuscarp.Size = new System.Drawing.Size(112, 35);
            this.btnBuscarp.TabIndex = 30;
            this.btnBuscarp.Text = "Buscar";
            this.btnBuscarp.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBuscarp.UseVisualStyleBackColor = true;
            this.btnBuscarp.Click += new System.EventHandler(this.btnBuscarp_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.label14.Location = new System.Drawing.Point(300, 126);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(47, 20);
            this.label14.TabIndex = 29;
            this.label14.Text = "Id_C";
            // 
            // txtbuscar
            // 
            this.txtbuscar.Location = new System.Drawing.Point(359, 119);
            this.txtbuscar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtbuscar.Name = "txtbuscar";
            this.txtbuscar.Size = new System.Drawing.Size(90, 26);
            this.txtbuscar.TabIndex = 28;
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.label13.Image = ((System.Drawing.Image)(resources.GetObject("label13.Image")));
            this.label13.Location = new System.Drawing.Point(299, 97);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(333, 17);
            this.label13.TabIndex = 24;
            this.label13.Text = "Buscar un Registro ";
            this.label13.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnConsultaG
            // 
            this.btnConsultaG.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.btnConsultaG.Location = new System.Drawing.Point(299, 52);
            this.btnConsultaG.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnConsultaG.Name = "btnConsultaG";
            this.btnConsultaG.Size = new System.Drawing.Size(130, 35);
            this.btnConsultaG.TabIndex = 27;
            this.btnConsultaG.Text = "Consulta Gral";
            this.btnConsultaG.UseVisualStyleBackColor = true;
            this.btnConsultaG.Click += new System.EventHandler(this.btnConsultaG_Click);
            // 
            // btnGuardarp
            // 
            this.btnGuardarp.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.btnGuardarp.Location = new System.Drawing.Point(437, 51);
            this.btnGuardarp.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnGuardarp.Name = "btnGuardarp";
            this.btnGuardarp.Size = new System.Drawing.Size(78, 35);
            this.btnGuardarp.TabIndex = 26;
            this.btnGuardarp.Text = "Guardar";
            this.btnGuardarp.UseVisualStyleBackColor = true;
            this.btnGuardarp.Visible = false;
            this.btnGuardarp.Click += new System.EventHandler(this.btnGuardarp_Click);
            // 
            // TxtId_Cp
            // 
            this.TxtId_Cp.Location = new System.Drawing.Point(82, 22);
            this.TxtId_Cp.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.TxtId_Cp.Name = "TxtId_Cp";
            this.TxtId_Cp.Size = new System.Drawing.Size(148, 26);
            this.TxtId_Cp.TabIndex = 25;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.label12.Location = new System.Drawing.Point(9, 22);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(43, 20);
            this.label12.TabIndex = 24;
            this.label12.Text = "Id_C";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AccessibleName = "";
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column8});
            this.dataGridView1.GridColor = System.Drawing.SystemColors.ActiveCaption;
            this.dataGridView1.Location = new System.Drawing.Point(8, 234);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.Size = new System.Drawing.Size(760, 194);
            this.dataGridView1.TabIndex = 22;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Id_C";
            this.Column1.MinimumWidth = 8;
            this.Column1.Name = "Column1";
            this.Column1.Width = 150;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Nombre";
            this.Column2.MinimumWidth = 8;
            this.Column2.Name = "Column2";
            this.Column2.Width = 150;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Correo";
            this.Column3.MinimumWidth = 8;
            this.Column3.Name = "Column3";
            this.Column3.Width = 150;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Telefono";
            this.Column4.MinimumWidth = 8;
            this.Column4.Name = "Column4";
            this.Column4.Width = 150;
            // 
            // Column8
            // 
            this.Column8.HeaderText = "Direccion";
            this.Column8.MinimumWidth = 8;
            this.Column8.Name = "Column8";
            this.Column8.Width = 150;
            // 
            // BtnModificarP
            // 
            this.BtnModificarP.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.BtnModificarP.Image = ((System.Drawing.Image)(resources.GetObject("BtnModificarP.Image")));
            this.BtnModificarP.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.BtnModificarP.Location = new System.Drawing.Point(398, 8);
            this.BtnModificarP.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.BtnModificarP.Name = "BtnModificarP";
            this.BtnModificarP.Size = new System.Drawing.Size(100, 35);
            this.BtnModificarP.TabIndex = 14;
            this.BtnModificarP.Text = "Modificar";
            this.BtnModificarP.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BtnModificarP.UseVisualStyleBackColor = true;
            this.BtnModificarP.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // btnEliminar
            // 
            this.btnEliminar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnEliminar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.btnEliminar.Image = ((System.Drawing.Image)(resources.GetObject("btnEliminar.Image")));
            this.btnEliminar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEliminar.Location = new System.Drawing.Point(523, 51);
            this.btnEliminar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(91, 35);
            this.btnEliminar.TabIndex = 13;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEliminar.UseVisualStyleBackColor = true;
            this.btnEliminar.Click += new System.EventHandler(this.btnEliminar_Click);
            // 
            // btnAgregar
            // 
            this.btnAgregar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAgregar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.btnAgregar.Image = ((System.Drawing.Image)(resources.GetObject("btnAgregar.Image")));
            this.btnAgregar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAgregar.Location = new System.Drawing.Point(299, 7);
            this.btnAgregar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(91, 35);
            this.btnAgregar.TabIndex = 12;
            this.btnAgregar.Text = "Agregar";
            this.btnAgregar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAgregar.UseVisualStyleBackColor = true;
            this.btnAgregar.Click += new System.EventHandler(this.btnAgregar_Click_1);
            // 
            // txtTelefonop
            // 
            this.txtTelefonop.Location = new System.Drawing.Point(88, 121);
            this.txtTelefonop.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtTelefonop.Name = "txtTelefonop";
            this.txtTelefonop.Size = new System.Drawing.Size(142, 26);
            this.txtTelefonop.TabIndex = 11;
            // 
            // txtCorreop
            // 
            this.txtCorreop.Location = new System.Drawing.Point(82, 88);
            this.txtCorreop.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtCorreop.Name = "txtCorreop";
            this.txtCorreop.Size = new System.Drawing.Size(148, 26);
            this.txtCorreop.TabIndex = 10;
            // 
            // txtNombrep
            // 
            this.txtNombrep.Location = new System.Drawing.Point(82, 55);
            this.txtNombrep.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtNombrep.Name = "txtNombrep";
            this.txtNombrep.Size = new System.Drawing.Size(148, 26);
            this.txtNombrep.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.label5.Location = new System.Drawing.Point(9, 124);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 20);
            this.label5.TabIndex = 8;
            this.label5.Text = "Telefono";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.label3.Location = new System.Drawing.Point(9, 88);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 20);
            this.label3.TabIndex = 7;
            this.label3.Text = "Correo";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.label2.Location = new System.Drawing.Point(9, 55);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 20);
            this.label2.TabIndex = 6;
            this.label2.Text = "Nombre";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.SteelBlue;
            this.tabPage2.Controls.Add(this.txtId_Ce);
            this.tabPage2.Controls.Add(this.label23);
            this.tabPage2.Controls.Add(this.txtNo_Orden);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.btncanceld);
            this.tabPage2.Controls.Add(this.btnbuscarD);
            this.tabPage2.Controls.Add(this.label16);
            this.tabPage2.Controls.Add(this.txtId_Ct1);
            this.tabPage2.Controls.Add(this.btnConsultaD);
            this.tabPage2.Controls.Add(this.dataGridView2);
            this.tabPage2.Controls.Add(this.label15);
            this.tabPage2.Controls.Add(this.btnGuardarD);
            this.tabPage2.Controls.Add(this.btnModificarD);
            this.tabPage2.Controls.Add(this.btneliminarD);
            this.tabPage2.Controls.Add(this.btnagregarD);
            this.tabPage2.Controls.Add(this.txtHora);
            this.tabPage2.Controls.Add(this.txtFecha);
            this.tabPage2.Controls.Add(this.txtId_Ct);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPage2.Size = new System.Drawing.Size(778, 473);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Cita";
            // 
            // txtNo_Orden
            // 
            this.txtNo_Orden.Location = new System.Drawing.Point(92, 123);
            this.txtNo_Orden.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtNo_Orden.Name = "txtNo_Orden";
            this.txtNo_Orden.Size = new System.Drawing.Size(191, 26);
            this.txtNo_Orden.TabIndex = 36;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.label10.Location = new System.Drawing.Point(2, 123);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(82, 20);
            this.label10.TabIndex = 35;
            this.label10.Text = "No_Orden";
            // 
            // btncanceld
            // 
            this.btncanceld.Location = new System.Drawing.Point(617, 49);
            this.btncanceld.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btncanceld.Name = "btncanceld";
            this.btncanceld.Size = new System.Drawing.Size(87, 39);
            this.btncanceld.TabIndex = 34;
            this.btncanceld.Text = "Cancelar";
            this.btncanceld.UseVisualStyleBackColor = true;
            this.btncanceld.Visible = false;
            this.btncanceld.Click += new System.EventHandler(this.btncanceld_Click);
            // 
            // btnbuscarD
            // 
            this.btnbuscarD.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.btnbuscarD.Image = ((System.Drawing.Image)(resources.GetObject("btnbuscarD.Image")));
            this.btnbuscarD.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnbuscarD.Location = new System.Drawing.Point(528, 138);
            this.btnbuscarD.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnbuscarD.Name = "btnbuscarD";
            this.btnbuscarD.Size = new System.Drawing.Size(112, 35);
            this.btnbuscarD.TabIndex = 33;
            this.btnbuscarD.Text = "Buscar";
            this.btnbuscarD.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnbuscarD.UseVisualStyleBackColor = true;
            this.btnbuscarD.Click += new System.EventHandler(this.btnbuscarD_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.label16.Location = new System.Drawing.Point(356, 144);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(53, 20);
            this.label16.TabIndex = 32;
            this.label16.Text = "Id_Ct";
            // 
            // txtId_Ct1
            // 
            this.txtId_Ct1.Location = new System.Drawing.Point(415, 138);
            this.txtId_Ct1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtId_Ct1.Name = "txtId_Ct1";
            this.txtId_Ct1.Size = new System.Drawing.Size(90, 26);
            this.txtId_Ct1.TabIndex = 31;
            this.txtId_Ct1.TextChanged += new System.EventHandler(this.txtId_Ct1_TextChanged);
            // 
            // btnConsultaD
            // 
            this.btnConsultaD.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.btnConsultaD.Location = new System.Drawing.Point(355, 51);
            this.btnConsultaD.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnConsultaD.Name = "btnConsultaD";
            this.btnConsultaD.Size = new System.Drawing.Size(130, 35);
            this.btnConsultaD.TabIndex = 28;
            this.btnConsultaD.Text = "Consulta Gral";
            this.btnConsultaD.UseVisualStyleBackColor = true;
            this.btnConsultaD.Click += new System.EventHandler(this.btnConsultaD_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column5,
            this.Column6,
            this.Column7,
            this.No_Orden,
            this.Id_C});
            this.dataGridView2.Location = new System.Drawing.Point(4, 205);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 62;
            this.dataGridView2.Size = new System.Drawing.Size(762, 194);
            this.dataGridView2.TabIndex = 26;
            // 
            // label15
            // 
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.label15.Image = ((System.Drawing.Image)(resources.GetObject("label15.Image")));
            this.label15.Location = new System.Drawing.Point(356, 95);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(249, 29);
            this.label15.TabIndex = 25;
            this.label15.Text = "Buscar un Registro \r\n";
            this.label15.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btnGuardarD
            // 
            this.btnGuardarD.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.btnGuardarD.Location = new System.Drawing.Point(493, 51);
            this.btnGuardarD.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnGuardarD.Name = "btnGuardarD";
            this.btnGuardarD.Size = new System.Drawing.Size(112, 35);
            this.btnGuardarD.TabIndex = 9;
            this.btnGuardarD.Text = "Guardar";
            this.btnGuardarD.UseVisualStyleBackColor = true;
            this.btnGuardarD.Visible = false;
            this.btnGuardarD.Click += new System.EventHandler(this.btnGuardarD_Click);
            // 
            // btnModificarD
            // 
            this.btnModificarD.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.btnModificarD.Image = ((System.Drawing.Image)(resources.GetObject("btnModificarD.Image")));
            this.btnModificarD.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnModificarD.Location = new System.Drawing.Point(458, 6);
            this.btnModificarD.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnModificarD.Name = "btnModificarD";
            this.btnModificarD.Size = new System.Drawing.Size(95, 35);
            this.btnModificarD.TabIndex = 8;
            this.btnModificarD.Text = "Modificar";
            this.btnModificarD.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnModificarD.UseVisualStyleBackColor = true;
            this.btnModificarD.Click += new System.EventHandler(this.btnModificarD_Click);
            // 
            // btneliminarD
            // 
            this.btneliminarD.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.btneliminarD.Image = ((System.Drawing.Image)(resources.GetObject("btneliminarD.Image")));
            this.btneliminarD.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btneliminarD.Location = new System.Drawing.Point(571, 8);
            this.btneliminarD.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btneliminarD.Name = "btneliminarD";
            this.btneliminarD.Size = new System.Drawing.Size(87, 35);
            this.btneliminarD.TabIndex = 7;
            this.btneliminarD.Text = "Eliminar";
            this.btneliminarD.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btneliminarD.UseVisualStyleBackColor = true;
            this.btneliminarD.Click += new System.EventHandler(this.btneliminarD_Click);
            // 
            // btnagregarD
            // 
            this.btnagregarD.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.btnagregarD.Image = ((System.Drawing.Image)(resources.GetObject("btnagregarD.Image")));
            this.btnagregarD.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnagregarD.Location = new System.Drawing.Point(355, 6);
            this.btnagregarD.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnagregarD.Name = "btnagregarD";
            this.btnagregarD.Size = new System.Drawing.Size(90, 35);
            this.btnagregarD.TabIndex = 6;
            this.btnagregarD.Text = "Agregar";
            this.btnagregarD.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnagregarD.UseVisualStyleBackColor = true;
            this.btnagregarD.Click += new System.EventHandler(this.btnagregarD_Click);
            // 
            // txtHora
            // 
            this.txtHora.Location = new System.Drawing.Point(92, 87);
            this.txtHora.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtHora.Name = "txtHora";
            this.txtHora.Size = new System.Drawing.Size(191, 26);
            this.txtHora.TabIndex = 5;
            this.txtHora.Text = "\r\n";
            // 
            // txtFecha
            // 
            this.txtFecha.Location = new System.Drawing.Point(92, 46);
            this.txtFecha.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtFecha.Name = "txtFecha";
            this.txtFecha.Size = new System.Drawing.Size(191, 26);
            this.txtFecha.TabIndex = 4;
            this.txtFecha.TextChanged += new System.EventHandler(this.txtFecha_TextChanged);
            // 
            // txtId_Ct
            // 
            this.txtId_Ct.Location = new System.Drawing.Point(92, 12);
            this.txtId_Ct.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtId_Ct.Name = "txtId_Ct";
            this.txtId_Ct.Size = new System.Drawing.Size(191, 26);
            this.txtId_Ct.TabIndex = 3;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.label8.Location = new System.Drawing.Point(4, 82);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 20);
            this.label8.TabIndex = 2;
            this.label8.Text = "Hora";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.label7.Location = new System.Drawing.Point(4, 49);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 20);
            this.label7.TabIndex = 1;
            this.label7.Text = "Fecha";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.label6.Location = new System.Drawing.Point(9, 17);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 20);
            this.label6.TabIndex = 0;
            this.label6.Text = "Id_Ct";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.RosyBrown;
            this.tabPage3.Controls.Add(this.dataGridView3);
            this.tabPage3.Controls.Add(this.button7);
            this.tabPage3.Controls.Add(this.label21);
            this.tabPage3.Controls.Add(this.txtId_VO2);
            this.tabPage3.Controls.Add(this.label22);
            this.tabPage3.Controls.Add(this.button4);
            this.tabPage3.Controls.Add(this.button5);
            this.tabPage3.Controls.Add(this.button6);
            this.tabPage3.Controls.Add(this.button2);
            this.tabPage3.Controls.Add(this.button3);
            this.tabPage3.Controls.Add(this.button1);
            this.tabPage3.Controls.Add(this.txtCosto);
            this.tabPage3.Controls.Add(this.txtAncho_v);
            this.tabPage3.Controls.Add(this.txtLargo_v);
            this.tabPage3.Controls.Add(this.txtTipo_Ventana);
            this.tabPage3.Controls.Add(this.txtId_VO);
            this.tabPage3.Controls.Add(this.label20);
            this.tabPage3.Controls.Add(this.label19);
            this.tabPage3.Controls.Add(this.label18);
            this.tabPage3.Controls.Add(this.label17);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Location = new System.Drawing.Point(4, 29);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.tabPage3.Size = new System.Drawing.Size(778, 473);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "VentanaOrden";
            // 
            // dataGridView3
            // 
            this.dataGridView3.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.Column9});
            this.dataGridView3.Location = new System.Drawing.Point(4, 206);
            this.dataGridView3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowHeadersWidth = 62;
            this.dataGridView3.Size = new System.Drawing.Size(671, 194);
            this.dataGridView3.TabIndex = 42;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.HeaderText = "Id_VO";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 150;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Tipo_Ventana";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 150;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "Largo_v";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 150;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.HeaderText = "Ancho_v";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 150;
            // 
            // Column9
            // 
            this.Column9.HeaderText = "Costo";
            this.Column9.MinimumWidth = 8;
            this.Column9.Name = "Column9";
            this.Column9.Width = 150;
            // 
            // button7
            // 
            this.button7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.button7.Image = ((System.Drawing.Image)(resources.GetObject("button7.Image")));
            this.button7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button7.Location = new System.Drawing.Point(517, 129);
            this.button7.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(112, 35);
            this.button7.TabIndex = 41;
            this.button7.Text = "Buscar";
            this.button7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.BtnBuscarVentana_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.label21.Location = new System.Drawing.Point(344, 144);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(60, 20);
            this.label21.TabIndex = 40;
            this.label21.Text = "Id_VO";
            this.label21.Click += new System.EventHandler(this.label21_Click);
            // 
            // txtId_VO2
            // 
            this.txtId_VO2.Location = new System.Drawing.Point(403, 138);
            this.txtId_VO2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtId_VO2.Name = "txtId_VO2";
            this.txtId_VO2.Size = new System.Drawing.Size(90, 26);
            this.txtId_VO2.TabIndex = 39;
            this.txtId_VO2.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label22
            // 
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.label22.Image = ((System.Drawing.Image)(resources.GetObject("label22.Image")));
            this.label22.Location = new System.Drawing.Point(344, 95);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(249, 29);
            this.label22.TabIndex = 38;
            this.label22.Text = "Buscar un Registro \r\n";
            this.label22.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(603, 53);
            this.button4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(87, 39);
            this.button4.TabIndex = 37;
            this.button4.Text = "Cancelar";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Visible = false;
            // 
            // button5
            // 
            this.button5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.button5.Location = new System.Drawing.Point(341, 55);
            this.button5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(130, 35);
            this.button5.TabIndex = 36;
            this.button5.Text = "Consulta Gral";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.BtnConsultaVentanas_Click);
            // 
            // button6
            // 
            this.button6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.button6.Location = new System.Drawing.Point(479, 55);
            this.button6.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(112, 35);
            this.button6.TabIndex = 35;
            this.button6.Text = "Guardar";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Visible = false;
            this.button6.Click += new System.EventHandler(this.BtnGuardarVentana);
            // 
            // button2
            // 
            this.button2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.button2.Image = ((System.Drawing.Image)(resources.GetObject("button2.Image")));
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button2.Location = new System.Drawing.Point(439, 10);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(95, 35);
            this.button2.TabIndex = 13;
            this.button2.Text = "Modificar";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.BtnModificarVentana_Click);
            // 
            // button3
            // 
            this.button3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button3.Location = new System.Drawing.Point(542, 10);
            this.button3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(87, 35);
            this.button3.TabIndex = 12;
            this.button3.Text = "Eliminar";
            this.button3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.BtnEliminarVentana_ClickV);
            // 
            // button1
            // 
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button1.Location = new System.Drawing.Point(341, 10);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(90, 35);
            this.button1.TabIndex = 11;
            this.button1.Text = "Agregar";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.BtnAgregarVentana_Click);
            // 
            // txtCosto
            // 
            this.txtCosto.Location = new System.Drawing.Point(141, 153);
            this.txtCosto.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtCosto.Name = "txtCosto";
            this.txtCosto.Size = new System.Drawing.Size(154, 26);
            this.txtCosto.TabIndex = 10;
            // 
            // txtAncho_v
            // 
            this.txtAncho_v.Location = new System.Drawing.Point(141, 117);
            this.txtAncho_v.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtAncho_v.Name = "txtAncho_v";
            this.txtAncho_v.Size = new System.Drawing.Size(154, 26);
            this.txtAncho_v.TabIndex = 9;
            // 
            // txtLargo_v
            // 
            this.txtLargo_v.Location = new System.Drawing.Point(141, 81);
            this.txtLargo_v.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtLargo_v.Name = "txtLargo_v";
            this.txtLargo_v.Size = new System.Drawing.Size(154, 26);
            this.txtLargo_v.TabIndex = 8;
            // 
            // txtTipo_Ventana
            // 
            this.txtTipo_Ventana.Location = new System.Drawing.Point(141, 45);
            this.txtTipo_Ventana.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtTipo_Ventana.Name = "txtTipo_Ventana";
            this.txtTipo_Ventana.Size = new System.Drawing.Size(154, 26);
            this.txtTipo_Ventana.TabIndex = 7;
            // 
            // txtId_VO
            // 
            this.txtId_VO.Location = new System.Drawing.Point(141, 10);
            this.txtId_VO.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtId_VO.Name = "txtId_VO";
            this.txtId_VO.Size = new System.Drawing.Size(154, 26);
            this.txtId_VO.TabIndex = 6;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.label20.Location = new System.Drawing.Point(9, 10);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(55, 20);
            this.label20.TabIndex = 5;
            this.label20.Text = "Id_VO";
            this.label20.Click += new System.EventHandler(this.label20_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.label19.Location = new System.Drawing.Point(9, 45);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(109, 20);
            this.label19.TabIndex = 4;
            this.label19.Text = "Tipo_Ventana";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.label18.Location = new System.Drawing.Point(9, 81);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(66, 20);
            this.label18.TabIndex = 3;
            this.label18.Text = "Largo_v";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.label17.Location = new System.Drawing.Point(9, 117);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(71, 20);
            this.label17.TabIndex = 2;
            this.label17.Text = "Ancho_v";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.label11.Location = new System.Drawing.Point(9, 153);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(51, 20);
            this.label11.TabIndex = 1;
            this.label11.Text = "Costo";
            // 
            // fensterDataSet1BindingSource
            // 
            this.fensterDataSet1BindingSource.DataSource = this.fensterDataSet1;
            this.fensterDataSet1BindingSource.Position = 0;
            // 
            // fensterDataSet1
            // 
            this.fensterDataSet1.DataSetName = "FensterDataSet1";
            this.fensterDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // txtId_Ce
            // 
            this.txtId_Ce.Location = new System.Drawing.Point(95, 157);
            this.txtId_Ce.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtId_Ce.Name = "txtId_Ce";
            this.txtId_Ce.Size = new System.Drawing.Size(191, 26);
            this.txtId_Ce.TabIndex = 38;
            this.txtId_Ce.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(47)))), ((int)(((byte)(61)))), ((int)(((byte)(128)))));
            this.label23.Location = new System.Drawing.Point(12, 162);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(43, 20);
            this.label23.TabIndex = 37;
            this.label23.Text = "Id_C";
            this.label23.Click += new System.EventHandler(this.label23_Click);
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Id_Ct";
            this.Column5.MinimumWidth = 8;
            this.Column5.Name = "Column5";
            this.Column5.Width = 150;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Fecha";
            this.Column6.MinimumWidth = 8;
            this.Column6.Name = "Column6";
            this.Column6.Width = 150;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "Hora";
            this.Column7.MinimumWidth = 8;
            this.Column7.Name = "Column7";
            this.Column7.Width = 150;
            // 
            // No_Orden
            // 
            this.No_Orden.HeaderText = "No_Orden";
            this.No_Orden.MinimumWidth = 8;
            this.No_Orden.Name = "No_Orden";
            this.No_Orden.Width = 150;
            // 
            // Id_C
            // 
            this.Id_C.HeaderText = "Id_C";
            this.Id_C.MinimumWidth = 8;
            this.Id_C.Name = "Id_C";
            this.Id_C.Width = 150;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(216)))), ((int)(((byte)(238)))));
            this.ClientSize = new System.Drawing.Size(799, 605);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ll";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fensterDataSet1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fensterDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.peliculaBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton2;
        private System.Windows.Forms.ToolStripMenuItem salirToolStripMenuItem;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button BtnModificarP;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.TextBox txtTelefonop;
        private System.Windows.Forms.TextBox txtCorreop;
        private System.Windows.Forms.TextBox txtNombrep;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox txtHora;
        private System.Windows.Forms.TextBox txtFecha;
        private System.Windows.Forms.TextBox txtId_Ct;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button btneliminarD;
        private System.Windows.Forms.Button btnagregarD;
        private System.Windows.Forms.BindingSource peliculaBindingSource;
        private System.Windows.Forms.TextBox TxtId_Cp;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnGuardarp;
        private System.Windows.Forms.Button btnConsultaG;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnBuscarp;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtbuscar;
        private System.Windows.Forms.Button btnModificarD;
        private System.Windows.Forms.Button btnGuardarD;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button btnConsultaD;
        private System.Windows.Forms.Button btnbuscarD;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtId_Ct1;
        private System.Windows.Forms.Button btncancelm;
        private System.Windows.Forms.Button btncanceld;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtDireccionp;
        private System.Windows.Forms.BindingSource fensterDataSet1BindingSource;
        private FensterDataSet1 fensterDataSet1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtNo_Orden;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.ToolStripMenuItem ventanaOrdenToolStripMenuItem;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtId_VO2;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtCosto;
        private System.Windows.Forms.TextBox txtAncho_v;
        private System.Windows.Forms.TextBox txtLargo_v;
        private System.Windows.Forms.TextBox txtTipo_Ventana;
        private System.Windows.Forms.TextBox txtId_VO;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.TextBox txtId_Ce;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn No_Orden;
        private System.Windows.Forms.DataGridViewTextBoxColumn Id_C;
    }
}

